package meli.spoiledTomatoesAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpoiledTomatoesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
